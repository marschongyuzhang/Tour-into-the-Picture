clear
clc
close all

%%
gui